package com.dg.chicken.diaplay;

public class Title {
	public static final String TITLE = 
			"****************************************\n"
		   +"*********    CHICKEN V.0.8.1   *********\n"	   
		   +"****************************************";
}
