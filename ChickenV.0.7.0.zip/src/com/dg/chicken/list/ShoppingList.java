package com.dg.chicken.list;

import java.util.ArrayList;

import com.dg.chicken.data.Product;

public class ShoppingList {
	public static ArrayList<Product> products = new ArrayList<Product>();
}
