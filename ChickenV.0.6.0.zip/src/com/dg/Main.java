package com.dg;

public class Main {
	public static void main(String[] args) {
		DgChicken dgChicken = new DgChicken();
		dgChicken.proc();
	}
}
