package com.dg.chicken.diaplay;

public class Title {
	public static final String TITLE = 
			"****************************************\n"
		   +"*********    CHICKEN V.0.3.0   *********\n"	   
		   +"****************************************";;
}
