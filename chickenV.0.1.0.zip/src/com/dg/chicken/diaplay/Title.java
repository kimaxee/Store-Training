package com.dg.chicken.diaplay;

public class Title {
	public static final String TITLE = 
			"****************************************\n"
		   +"*********    CHICKEN V.0.1.0   *********\n"	   
		   +"****************************************";;
}
